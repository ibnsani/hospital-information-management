<?php

?>



		

	<body>
	<?php
	require('db.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['email'])){
		
		$email = stripslashes($_REQUEST['email']); // removes backslashes
		$email = mysqli_real_escape_string($con,$email); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE email='$email' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['email'] = $email;
			$_SESSION['name'] = $username;
			
			
			header("Location: index.php"); // Redirect user to index.php
            }else{
				header( "refresh:4;url=login.php" ); 
 echo "<div class='form'><h3 align='center' style='color:#009900'>Username/password is incorrect.</h3><br/></div>";
  echo "<h4 align='center'> You will be redirected in about 4 secs. If not, click <a href='login.php'>here</a></h4>";
          
				//echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
?>
		<div class="container">
			<div class="row main">
				<div class="panel-heading">
	               <div class="panel-title text-center">
	               		<h1 class="title">H.M.S</h1>
	               		<hr />
	               	</div>
	            </div> 

				<div class="main-login main-center">
					<form class="form-horizontal" method="post" action="#">
						
						

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="email" class="form-control" name="email" id="email"  placeholder="Enter your Email" required/>
								</div>
							</div>
						</div>

						

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password" required/>
								</div>
							</div>
						</div>

						

						<div class="form-group" align="center">
						<input name="submit" type="submit" class="btn btn-primary btn-md login-button" value="Login" />
							
						</div>
						<div class="login-register">
						<p>Not registered yet? <a href='registration.php'>Register Here</a></p>
						
						<p>Forget password? <a href='forget.php'>Click Here</a></p>
				            
				         </div>
					</form>
				</div>
			</div>
		</div>
<?php } ?>
		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
	</body>
</html>